import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Values from './components/Values';
import VirtualTour from './components/VirtualTour';
import Directory from './components/Directory';
import Admissions from './components/Admissions';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Values />
      <VirtualTour />
      <Directory />
      <Admissions />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
