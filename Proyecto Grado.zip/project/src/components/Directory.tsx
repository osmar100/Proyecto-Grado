import { Building2, FlaskConical, GraduationCap, Trophy, Utensils, Church, Music, Users } from 'lucide-react';

export default function Directory() {
  const areas = [
    {
      icon: Building2,
      name: 'Aulas',
      description: 'Salones equipados con tecnología moderna',
    },
    {
      icon: FlaskConical,
      name: 'Laboratorios',
      description: 'Ciencias, Física, Química y Computación',
    },
    {
      icon: GraduationCap,
      name: 'Oficinas Administrativas',
      description: 'Dirección, Secretaría y Administración',
    },
    {
      icon: Trophy,
      name: 'Instalaciones Deportivas',
      description: 'Canchas multiuso y áreas recreativas',
    },
    {
      icon: Utensils,
      name: 'Cafetería',
      description: 'Servicio de alimentación y comedor',
    },
    {
      icon: Church,
      name: 'Capilla',
      description: 'Espacio de oración y reflexión',
    },
    {
      icon: Music,
      name: 'Área de Música',
      description: 'Espacios para actividades musicales',
    },
    {
      icon: Users,
      name: 'Patio Institucional',
      description: 'Amplio espacio al aire libre para actividades recreativas y eventos escolares',
    },
  ];

  return (
    <section id="directorio" className="py-20 bg-navy-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Directorio <span className="text-yellow-400">del Campus</span>
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Encuentra fácilmente las diferentes áreas y servicios de nuestra institución
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {areas.map((area, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer group"
            >
              <div className="bg-yellow-400 w-14 h-14 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <area.icon className="w-7 h-7 text-navy-700" />
              </div>
              <h3 className="text-xl font-bold text-navy-700 mb-2">{area.name}</h3>
              <p className="text-gray-600 text-sm">{area.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">¿Necesitas ayuda para ubicarte?</h3>
          <p className="text-gray-300 mb-6">
            Nuestro personal está disponible para asistirte en tu visita
          </p>
          <a
            href="#contacto"
            className="inline-block bg-yellow-400 text-navy-700 px-8 py-3 rounded-full font-bold hover:bg-yellow-500 transition-all duration-300"
          >
            Contactar Información
          </a>
        </div>
      </div>
    </section>
  );
}
