import { CheckCircle2, Calendar, FileText, UserCheck } from 'lucide-react';

export default function Admissions() {
  const steps = [
    {
      icon: FileText,
      title: 'Solicitud',
      description: 'Completa el formulario de admisión en línea',
    },
    {
      icon: Calendar,
      title: 'Entrevista',
      description: 'Programa una entrevista con nuestro equipo',
    },
    {
      icon: UserCheck,
      title: 'Evaluación',
      description: 'Evaluación académica y de competencias',
    },
    {
      icon: CheckCircle2,
      title: 'Admisión',
      description: 'Recibe tu carta de aceptación',
    },
  ];

  return (
    <section id="admisiones" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-navy-700 mb-4">
            Proceso de <span className="text-yellow-500">Admisiones</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Únete a nuestra comunidad educativa en 4 simples pasos
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="relative mb-6">
                <div className="bg-yellow-400 w-20 h-20 rounded-full flex items-center justify-center mx-auto shadow-lg">
                  <step.icon className="w-10 h-10 text-navy-700" />
                </div>
                <div className="absolute -top-2 -right-2 bg-navy-700 text-yellow-400 w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">
                  {index + 1}
                </div>
              </div>
              <h3 className="text-xl font-bold text-navy-700 mb-2">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-navy-700 to-navy-600 rounded-2xl p-8 md:p-12 text-center text-white">
          <h3 className="text-3xl font-bold mb-4">Admisiones Abiertas 2025</h3>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Inicia el camino hacia una educación de excelencia. ¡Las inscripciones están abiertas!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-yellow-400 text-navy-700 px-8 py-4 rounded-full font-bold text-lg hover:bg-yellow-500 transition-all duration-300 transform hover:scale-105">
              Solicitar Información
            </button>
            <button className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white hover:text-navy-700 transition-all duration-300">
              Descargar Prospecto
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
