import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-navy-700 text-white pt-12 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSK4RS6t53JmphwQ40hyqJoU6otH3sZgVdlQ&s"
                alt="UEPDC Logo"
                className="h-12 w-12 object-contain"
              />
              <div>
                <h3 className="text-xl font-bold">UEPDC</h3>
                <p className="text-xs text-gray-400">¡Ven y Verás!</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              Formando líderes con valores cristianos y excelencia académica.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 text-yellow-400">Enlaces Rápidos</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#inicio" className="hover:text-yellow-400 transition-colors">Inicio</a></li>
              <li><a href="#informacion" className="hover:text-yellow-400 transition-colors">Información</a></li>
              <li><a href="#tour" className="hover:text-yellow-400 transition-colors">Tour Virtual</a></li>
              <li><a href="#directorio" className="hover:text-yellow-400 transition-colors">Directorio</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 text-yellow-400">Servicios</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#admisiones" className="hover:text-yellow-400 transition-colors">Admisiones</a></li>
              <li><a href="#contacto" className="hover:text-yellow-400 transition-colors">Contacto</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Portal Padres</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Portal Estudiantes</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 text-yellow-400">Síguenos</h4>
            <div className="flex gap-3">
              <a
                href="#"
                className="bg-white/10 p-3 rounded-full hover:bg-yellow-400 hover:text-navy-700 transition-all duration-300"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="bg-white/10 p-3 rounded-full hover:bg-yellow-400 hover:text-navy-700 transition-all duration-300"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="bg-white/10 p-3 rounded-full hover:bg-yellow-400 hover:text-navy-700 transition-all duration-300"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="bg-white/10 p-3 rounded-full hover:bg-yellow-400 hover:text-navy-700 transition-all duration-300"
              >
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-6 text-center text-gray-400 text-sm">
          <p>&copy; 2025 UEPDC - Colegio. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
