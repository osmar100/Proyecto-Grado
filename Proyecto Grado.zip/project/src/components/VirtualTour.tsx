import { Maximize2, ExternalLink } from 'lucide-react';

export default function VirtualTour() {
  return (
    <section id="tour" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-navy-700 mb-4">
            Tour Virtual <span className="text-yellow-500">360°</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto mb-6">
            Explora nuestras instalaciones desde la comodidad de tu hogar. Recorre aulas, laboratorios,
            canchas deportivas y más en una experiencia interactiva inmersiva.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="relative" style={{ paddingBottom: '56.25%' }}>
            <iframe
              src="https://kuula.co/share/collection/7YddL?logo=1&info=1&fs=1&vr=0&sd=1&thumbs=1"
              width="100%"
              height="100%"
              className="absolute top-0 left-0 w-full h-full"
              frameBorder="0"
              allow="xr-spatial-tracking; gyroscope; accelerometer"
              allowFullScreen
              title="Tour Virtual 360° - UEPDC"
            />
          </div>

          <div className="p-6 bg-navy-700 flex flex-wrap gap-4 justify-between items-center">
            <div className="text-white">
              <h3 className="font-bold text-lg mb-1">Recorrido Completo del Campus</h3>
              <p className="text-gray-300 text-sm">Haz clic y arrastra para explorar en 360°</p>
            </div>
            <div className="flex gap-3">
              <button className="flex items-center gap-2 bg-yellow-400 text-navy-700 px-6 py-3 rounded-full font-bold hover:bg-yellow-500 transition-all duration-300">
                <Maximize2 className="w-4 h-4" />
                Pantalla Completa
              </button>
              <a
                href="https://kuula.co/share/collection/7YddL?logo=1&info=1&fs=1&vr=0&sd=1&thumbs=1"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-transparent border-2 border-yellow-400 text-yellow-400 px-6 py-3 rounded-full font-bold hover:bg-yellow-400 hover:text-navy-700 transition-all duration-300"
              >
                <ExternalLink className="w-4 h-4" />
                Abrir en Nueva Ventana
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-md text-center">
            <div className="text-4xl font-bold text-yellow-500 mb-2">15+</div>
            <p className="text-navy-700 font-medium">Áreas Disponibles</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md text-center">
            <div className="text-4xl font-bold text-yellow-500 mb-2">360°</div>
            <p className="text-navy-700 font-medium">Vista Panorámica</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md text-center">
            <div className="text-4xl font-bold text-yellow-500 mb-2">24/7</div>
            <p className="text-navy-700 font-medium">Acceso Ilimitado</p>
          </div>
        </div>
      </div>
    </section>
  );
}
