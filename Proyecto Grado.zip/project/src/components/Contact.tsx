import { Mail, Phone, MapPin, Clock } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contacto" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-navy-700 mb-4">
            Contáctanos
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Estamos aquí para responder todas tus preguntas
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <div className="bg-white rounded-2xl p-8 shadow-lg mb-8">
              <h3 className="text-2xl font-bold text-navy-700 mb-6">Información de Contacto</h3>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-yellow-400 p-3 rounded-full">
                    <MapPin className="w-6 h-6 text-navy-700" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy-700 mb-1">Dirección</h4>
                    <p className="text-gray-600">Guasmo Sur, Coop. Francisco de Orellana Mz.2078</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-yellow-400 p-3 rounded-full">
                    <Phone className="w-6 h-6 text-navy-700" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy-700 mb-1">Teléfono</h4>
                    <p className="text-gray-600">+593 98 458 3726</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-yellow-400 p-3 rounded-full">
                    <Mail className="w-6 h-6 text-navy-700" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy-700 mb-1">Email</h4>
                    <p className="text-gray-600">secretaria@uepdc.edu.ec</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-yellow-400 p-3 rounded-full">
                    <Clock className="w-6 h-6 text-navy-700" />
                  </div>
                  <div>
                    <h4 className="font-bold text-navy-700 mb-1">Horario</h4>
                    <p className="text-gray-600">Lunes a Viernes: 7:00 AM - 5:00 PM</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-navy-700 rounded-2xl p-8 text-white">
              <h3 className="text-xl font-bold mb-4">¿Por qué elegirnos?</h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                  <span>Excelencia académica comprobada</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                  <span>Educación en valores cristianos</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                  <span>Infraestructura moderna</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                  <span>Personal altamente calificado</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-navy-700 mb-6">Envíanos un Mensaje</h3>
            <form className="space-y-6">
              <div>
                <label className="block text-navy-700 font-medium mb-2">Nombre Completo</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-yellow-400 focus:outline-none transition-colors"
                  placeholder="Tu nombre"
                />
              </div>

              <div>
                <label className="block text-navy-700 font-medium mb-2">Email</label>
                <input
                  type="email"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-yellow-400 focus:outline-none transition-colors"
                  placeholder="tu@email.com"
                />
              </div>

              <div>
                <label className="block text-navy-700 font-medium mb-2">Teléfono</label>
                <input
                  type="tel"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-yellow-400 focus:outline-none transition-colors"
                  placeholder="+593 98 XXX XXXX"
                />
              </div>

              <div>
                <label className="block text-navy-700 font-medium mb-2">Mensaje</label>
                <textarea
                  rows={4}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-yellow-400 focus:outline-none transition-colors resize-none"
                  placeholder="Escribe tu mensaje aquí..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-yellow-400 text-navy-700 py-4 rounded-xl font-bold text-lg hover:bg-yellow-500 transition-all duration-300 transform hover:scale-105"
              >
                Enviar Mensaje
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
