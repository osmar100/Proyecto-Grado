import { Users, Sparkles, BookOpen, Heart, Shield, Lightbulb, Award } from 'lucide-react';

export default function Values() {
  const values = [
    {
      icon: Users,
      title: 'Comunidad',
      description: 'Permanecemos en una sola unión dentro de una familia.',
      color: 'bg-blue-500',
    },
    {
      icon: Sparkles,
      title: 'Oración',
      description: 'El valor de la oración, promueve el diálogo con Dios.',
      color: 'bg-purple-500',
    },
    {
      icon: BookOpen,
      title: 'Misión',
      description: 'La educación con espiritualidad misionera forma a los estudiantes.',
      color: 'bg-green-500',
    },
    {
      icon: Heart,
      title: 'Bondad',
      description: 'Buscar personas íntegras capaces de actuar con empatía.',
      color: 'bg-red-500',
    },
    {
      icon: Shield,
      title: 'Orden',
      description: 'Cultivamos la disciplina y estructura en todo lo que hacemos.',
      color: 'bg-yellow-500',
    },
    {
      icon: Lightbulb,
      title: 'Nobleza',
      description: 'Nos permite actuar con generosidad, honestidad y compasión.',
      color: 'bg-teal-500',
    },
    {
      icon: Award,
      title: 'Innovación',
      description: 'Es una herramienta poderosa para transformar la educación.',
      color: 'bg-orange-500',
    },
  ];

  return (
    <section id="informacion" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-navy-700 mb-4">
          Nuestros <span className="text-yellow-500">Valores</span>
        </h2>
        <p className="text-center text-gray-600 mb-16 max-w-2xl mx-auto">
          Principios fundamentales que guían nuestra labor educativa y forman el carácter de nuestros estudiantes
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-gray-100"
            >
              <div className={`${value.color} w-16 h-16 rounded-full flex items-center justify-center mb-4`}>
                <value.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-yellow-500 mb-3">{value.title}</h3>
              <p className="text-navy-700 leading-relaxed">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
