import { ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section id="inicio" className="relative bg-gradient-to-br from-navy-700 via-navy-600 to-navy-700 text-white pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="text-yellow-400">UEPDC</span> - Tour Virtual
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            ¡Ven y Verás! Formando líderes con valores cristianos, excelencia académica e innovación educativa
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#tour"
              className="bg-yellow-400 text-navy-700 px-8 py-4 rounded-full font-bold text-lg hover:bg-yellow-500 transition-all duration-300 transform hover:scale-105"
            >
              Explora Nuestro Campus
            </a>
            <a
              href="#admisiones"
              className="bg-transparent border-2 border-yellow-400 text-yellow-400 px-8 py-4 rounded-full font-bold text-lg hover:bg-yellow-400 hover:text-navy-700 transition-all duration-300"
            >
              Admisiones 2025
            </a>
          </div>
        </div>
      </div>
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-8 h-8 text-yellow-400" />
      </div>
    </section>
  );
}
